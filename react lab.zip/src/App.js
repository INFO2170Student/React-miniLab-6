import { useState } from "react";
import { Routes, Route } from "react-router-dom";
import uuid from "react-uuid";
import Form from "./components/Form/Form";
import Header from "./components/Header/Header"
import Tasks from "./components/Tasks/Tasks";
import Intro from "./components/Help/Intro";
import AddTask from "./components/Help/AddTask";
import RemoveTask from "./components/Help/RemoveTask";
import ChangeStatus from "./components/Help/ChangeStatus";
import PageNotFound from "./components/Help/PageNotFound/PageNotFound";

function App() {
  const [tasks, setTasks] = useState([
    {
        id:uuid(),
        description: "Did you do meditation today?",
        done: true
    },
    {
        id:uuid(),
        description: "Did you eat right today?",
        done: false
    },
    {
        id:uuid(),
        description: "Did you workout today?",
        done: false
    }
])

const handleClearTasks = () => {
    setTasks([]);
}

const handleResetTasks = () => {
    window.location.reload(false)
}

const handleStatusChange = (id) => {
    // console.log(id);
    const updatedTasks = [...tasks];
    updatedTasks.forEach((task) => {
        if(task.id === id){
            task.done = !task.done;
        }
    })
    setTasks(updatedTasks);
}

const handleTaskRemove = (id) => {
    // console.log(id);
    const filteredTasks = tasks.filter(
        (task) => task.id !== id
    )
    setTasks(filteredTasks);
}

const handleAddTask = (description, status) => {
  setTasks([
    ...tasks,
    {
      id: uuid(),
      description: description,
      done: status
    }
  ]);
}

  return (
    <>
    <Header></Header>
    <div className="main_container">
    <Routes>
      <Route path="/" element={ 
        <Tasks
        tasks={tasks}
        onStatusChange={handleStatusChange}
        onTaskRemove={handleTaskRemove}
        onClearTasks={handleClearTasks}
        onResetTasks={handleResetTasks}
      ></Tasks>
      } />
      <Route path="add" element={
        <Form
          onAddTask={handleAddTask}
        ></Form>
       } />
      <Route path="/help" element={ <Intro/>} >
       <Route path="add" element={<AddTask/>} />
       <Route path="remove" element={<RemoveTask/>} />
       <Route path="changeStatus" element={<ChangeStatus/>} />
      </Route>

      <Route path="*" element={ <PageNotFound/>} />
    </Routes>
    </div>
    </>
  );
}

export default App;
