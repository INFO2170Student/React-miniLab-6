// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC3hfnbh1AsfSWqOHJKh37T63-95-F6Ln4",
  authDomain: "todo-lab-6.firebaseapp.com",
  projectId: "todo-lab-6",
  storageBucket: "todo-lab-6.appspot.com",
  messagingSenderId: "733917767539",
  appId: "1:733917767539:web:8e92a0740d840975764706"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);