import { useState } from "react";
import {FaPlusCircle} from 'react-icons/fa'

function Form ({onAddTask}) {
    const [description, setDescription] = useState("");
    const [status, setStatus] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");

    const handleFormSubmission = (event) => {
        event.preventDefault();
        if(description === ""){
            setErrorMessage("Enter a description.");
        }
        else {
            // Add the task.
            onAddTask(description, status);

            // Reset the form State.
            setDescription("");
            setStatus(false);
            setErrorMessage("")
        }
    }

    return(
        <form onSubmit={handleFormSubmission} >
            <h2>Add a new task</h2>

            {errorMessage !== '' && (
                <div>{errorMessage}</div>
            )}

            <label htmlFor="description">Description: </label>
            <input 
                id="description" 
                type="text" 
                maxLength={150} 
                value={description}
                onChange={(event) => setDescription(event.target.value)}
            />

            <br></br>
            <label htmlFor="status">Status: </label> 
            <select 
                id="status"
                value={status}
                onChange={(event) => setStatus(event.target.value)}
            >
                <option value={false}>Open</option>
                <option value={true}>Completed</option>
            </select>
            
            <br></br>
            
            <button><FaPlusCircle />Add</button>
        </form>
    )
}

export default Form;