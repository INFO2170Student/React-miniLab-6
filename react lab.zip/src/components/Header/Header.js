import "./Header.scss";
import { FaTasks } from "react-icons/fa";
import MainMenu from "../MainMenu/MainMenu";

function Header() {
  return (
    <>
      <header>
        <div className="title">
          <FaTasks className="icon" />
          ToDo App
        </div>
        <div className="author">by Vishal Nandu</div>
      </header>
      <MainMenu />
    </>
  );
}
export default Header;
