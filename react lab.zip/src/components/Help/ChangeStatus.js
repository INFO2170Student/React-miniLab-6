import React from 'react';

function ChangeStatus() {

    return (
        <>
        <div className="help_subcontainer">
          <h2>Change Status</h2>
          <p>
            Change Status ad minim velit enim commodo enim nulla cillum officia laboris velit
            exercitation epor quis elit dolore occaecat commodo dolore ex deserunt
            cupidatat nostrud ipsum commodo elit ea ipsum esse ut culpa.
          </p>
          </div>
        </>
      );
}

export default ChangeStatus