import React from "react";
import { Outlet, useNavigate } from "react-router-dom";

function Intro() {
  const navigate = useNavigate();

  const handleHelpAdd = () => {
    navigate("/help/add");
  }

  const handleHelpRemove = () => {
    navigate("/help/remove");
  }

  const handleHelpChangeStatus = () => {
    navigate("/help/changeStatus");
  }
  return (
    <>
    <div className="help_container">
      <h2>Introduction</h2>
      <p>
        Introduction ad minim velit enim commodo enim nulla cillum officia laboris velit
        exercitation enim Duis id esse do cillum.
      </p>
      <Outlet/>
      <button onClick={handleHelpAdd}>Add Task</button>
      <button onClick={handleHelpRemove}>Remove Task</button>
      <button onClick={handleHelpChangeStatus}>Change Status</button>
      </div>
    </>
  );
}

export default Intro;
