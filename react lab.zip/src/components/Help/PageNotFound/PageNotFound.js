import React from "react";
import { useNavigate } from "react-router-dom";

function PageNotFound() {
  const navigate = useNavigate();

  const handleReturnHome = () => {
    navigate("/");
  }
  return (
    <>
      <div className="page_notfound">
        <h2>Page Not Found</h2>
        <p>Please check the address.</p>
        <button onClick={handleReturnHome}>Home</button>
      </div>
    </>
  );
}

export default PageNotFound;
