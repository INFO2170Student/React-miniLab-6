import React from 'react';

function RemoveTask() {

    return (
        <>
        <div className="help_subcontainer">
          <h2>Remove a Task</h2>
          <p>
            Remove Task askdcansbc ajscnbkascb ad minim velit enim commodo enim nulla cillum officia laboris velit
            exercitation enim Duis id esse do cillum. consequat irure anim lorem
            aliqua sed tempor quis elit dolore occaecat commodo dolore ex deserunt
            cupidatat nostrud ipsum commodo elit ea ipsum esse ut culpa.
          </p>
          </div>
        </>
      );
}

export default RemoveTask;