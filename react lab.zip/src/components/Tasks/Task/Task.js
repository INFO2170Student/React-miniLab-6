import React from "react";

function Task(props){
    const { id, description, done} = props.task;
    const { onStatusChange, onTaskRemove} = props;

    const handleStatusClick = () => {
        onStatusChange(id);
    }
    
    const handleRemoveClick = () => {
        onTaskRemove(id);
    }

    return(
        <div>
            <hr/>
            <h3>{description}</h3>
            <div>Id: {id}</div>
            <div>Status: {done ? 'Completed' : 'Open' }</div>
            <button className="primary-btn" onClick={handleStatusClick}> Change Status</button>
            <button className="danger-btn" onClick={handleRemoveClick}> Remove Task</button>
        </div>
    )
}

export default Task;