import uuid from "react-uuid";
import React,{useState} from "react";
import Task from './Task/Task';

function Tasks(props){
    const {tasks, onStatusChange, onTaskRemove, onClearTasks, onResetTasks } = props;

    return(
        <>
        <div className="tasks-container">
        <h2>These are the tasks:</h2>
        {tasks.map(
            (task, index) => (
                <Task 
                    key = {index}
                    task = {task}
                    onStatusChange = {onStatusChange}
                    onTaskRemove = {onTaskRemove}
                />
            )
        )}

        <hr/>
        <button className="danger-btn" onClick = {onClearTasks}> Clear All Tasks</button>
        <button className="secondary-btn" onClick = {onResetTasks}>Refresh All Tasks</button>
        </div>
        </>
    )
}

export default Tasks;
